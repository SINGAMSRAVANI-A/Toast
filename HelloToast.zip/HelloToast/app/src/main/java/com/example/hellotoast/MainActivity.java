package com.example.hellotoast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button b1;
    TextView tv;
    int a=0;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*b1=findViewById(R.id.countINC);*/
        tv=findViewById(R.id.textcount);

        /*b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //  Implement Action
                a++;
                tv.setText(""+a);
            }
        });*/
        if (savedInstanceState!=null && savedInstanceState.containsKey("sravani")){
            a=savedInstanceState.getInt("sravani");
            tv.setText(String.valueOf(a));
        }

    }

    public void message(View view) {
        Toast.makeText(this,"Welcome to android", Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("sravani",a);
    }

    public void reset(View view) {
        a=0;
        tv.setText(""+a);
    }

    public void increment(View view) {
        a=a+1;
        tv.setText(""+a);
    }

    public void decrement(View view) {
        a=a-1;
        tv.setText(""+a);

    }
}
